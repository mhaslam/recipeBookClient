import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Book } from '../../book.model';

@Component({
  selector: 'app-book-item',
  templateUrl: './book-item.component.html',
  styleUrl: './book-item.component.scss'
})
export class BookItemComponent {
  @Input() book: Book;
  @Input() index: number;
  @Output() bookClick = new EventEmitter<void>();

  onBookClick() {
    this.bookClick.emit();
  }
}


