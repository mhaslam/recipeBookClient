import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

  @ViewChild('offcanvas', { static: true }) offcanvas: ElementRef;
  @ViewChild('backdrop', { static: true }) backdrop: ElementRef;


  constructor(private renderer: Renderer2) {
    console.log('BooksComponent initialized');
  }

  ngOnInit(): void {
    console.log('BooksComponent ngOnInit');
  }

  openOffcanvas() {
    this.renderer.addClass(this.offcanvas.nativeElement, 'show');
    this.renderer.addClass(this.backdrop.nativeElement, 'show');
  }

  closeOffcanvas() {
    this.renderer.removeClass(this.offcanvas.nativeElement, 'show');
    this.renderer.removeClass(this.backdrop.nativeElement, 'show');
  }
}
