import { Component } from '@angular/core';

@Component({
  selector: 'app-book-start',
  templateUrl: './book-start.component.html',
  styleUrl: './book-start.component.css'
})
export class BookStartComponent {

}
